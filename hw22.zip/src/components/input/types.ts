export interface InputProps {
  placeholder: string; 
  disabled: boolean; 
  label: string;
}