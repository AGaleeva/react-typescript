import './App.css';
import Lesson20 from './lessons/lesson20';
import Homework20 from './homeworks/homework20';
import Lesson21 from './lessons/lesson21';
import Homework21 from './homeworks/homework21';
import Lesson22 from 'lessons/lesson22';
import Homework22 from 'homeworks/homework22';

function App() {
  return (
    <div className="App">      
      {/* <Lesson20 />  */}
      {/* <Lesson21 /> */}
      {/* <Lesson22 /> */}

      {/* <Homework20 /> */}
      {/* <Homework21 /> */}
      <Homework22 />
    </div>
  );
}

export default App;
