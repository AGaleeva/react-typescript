import Homework21 from "./Homework21";

export default Homework21;